<?php 

class ErrorController{
	
	public function Index(){
		echo "<h2 class='product-tittle'>La pagina que buscas no existe</h2>";
	}
}