<?php

define("base_url", "http://localhost:8081/udemy/2/tienda/");
define("controller_default", "ProductoController");
define("action_default", "index");