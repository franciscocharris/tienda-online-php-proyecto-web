
<div class=" bg-primary container h-100">
  <div class="row h-100 align-items-center">
    <div class="col-lg-12">
      <h1 class="display-4 text-white mt-5 mb-2">nombre del negocio</h1>
      <p class="lead mb-5 text-white-50">lema o slogan.</p>
    </div>
  </div>
</div>

<div class="col-md-8 mb-5" style="margin-top: 10px;">
        <h2>Que hacemos?</h2>
        <hr>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. A deserunt neque tempore recusandae animi soluta quasi? Asperiores rem dolore eaque vel, porro, soluta unde debitis aliquam laboriosam. Repellat explicabo, maiores!</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis optio neque consectetur consequatur magni in nisi, natus beatae quidem quam odit commodi ducimus totam eum, alias, adipisci nesciunt voluptate. Voluptatum.</p>
        <a class="btn btn-primary btn-lg" href="<?=base_url?>usuario/registro">Registrate &raquo;</a>
</div>
<div class="col-md-4 mb-5" style="margin-top: 10px;">
	<h2>Contactanos</h2>
	<hr>
	<address>
	  <strong>Direccion</strong>
	  <br>3481 Melrose Place
	  <br>Beverly Hills, CA 90210
	  <br>
	</address>
	<address>
	  <abbr title="Phone">Pbx :</abbr>
	  (123) 456-7890
	  <br>
	  <abbr title="Email">Email :</abbr>
	  <a href="mailto:fmcharris5@misena.edu.co">fmcharris5@misena.edu.co</a>
	</address>
</div>