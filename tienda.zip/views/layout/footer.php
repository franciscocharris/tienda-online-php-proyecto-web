 </div>
    <!-- /.row -->

  </div>
  <!-- /.container -->

  <!-- Footer -->
  <div class="iconos-contactar">
    <a  href="https://api.whatsapp.com/send?phone=573004844094&text=Hola%20quisiera%20hablar%20contigo%20sobre%20" target="_blank">
      <img src="<?=base_url?>assets/img/whatsapp.png">
    </a>
    <a href="http://m.me/100013541311546?ref=100013541311546" target="_blank">
      <img src="<?=base_url?>assets/img/facebook.png">
    </a>
  </div>
  
  <footer class="py-5 bg-dark">
    <div class="container">
        <p class="m-0 text-center text-white">Desarrollado por Francisco M. Charris C.  &copy;<?=date('Y');?>
          <a class="btn btn-primary"href="http://m.me/100013541311546?ref=100013541311546" target="_blank">
            Contactar
          </a>
        </p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="<?=base_url?>assets/vendor/jquery/jquery.min.js"></script>
  <script src="<?=base_url?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?=base_url?>assets/js/main.js" type="text/javascript"></script>
</body>

</html>
<?php ob_end_flush(); ?>
